#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int minResistenciaTotal(const vector<vector<int>>& M)
{
//TODO
}

int main()
{
    vector<vector<int>> M ={{2,1,3},{6,5,4},{7,8,9}};

    cout << "Minima Resistencia Total = " << minResistenciaTotal(M) << endl;
    return 0;
}
