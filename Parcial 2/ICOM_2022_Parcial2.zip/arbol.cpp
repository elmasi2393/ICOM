#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

struct TreeNode;

using Tree = TreeNode *;

const Tree EmptyTree = nullptr;

struct TreeNode {
	int valor;
	Tree left;
	Tree right;
	TreeNode(int v);  // TODO
	~TreeNode();	  // TODO
};

Tree TreeInsert(Tree t, int v)
{
	if (t == EmptyTree)
		return new TreeNode(v);
	if (v < t->valor)
		t->left = TreeInsert(t->left, v);
	else
		t->right = TreeInsert(t->right, v);
	return t;
}

std::vector<int> serializar(Tree t1);			// TODO

bool arboles_semejantes(Tree t1, Tree t2);		// TODO

Tree balancear(Tree t);							// TODO

int numNodos(Tree t)
{
	if (t == EmptyTree)
		return 0;
	return 1 + numNodos(t->left) + numNodos(t->right);
}

bool esta_balanceado(Tree t)
{
	if (t == EmptyTree)
		return true;

	int numNodos_left = numNodos(t->left);
	int numNodos_right = numNodos(t->right);
	if (abs(numNodos_left - numNodos_right) > 1)
		return false;

	return esta_balanceado(t->left) && esta_balanceado(t->right);
}


int main() {

	Tree t1 = EmptyTree;
	Tree t2 = EmptyTree;
	for (int i = 0; i < 100; i++) {
		t1 = TreeInsert(t1, i);
		t2 = TreeInsert(t2, 99-i);
	}

	cout << " semejantes: " << arboles_semejantes(t1, t2) << endl;

	Tree t = balancear(t1);


	cout << "numNodos t : " << numNodos(t) << endl;
	cout << "numNodos t1: " << numNodos(t1) << endl;
	cout << "Balance  t:  " << esta_balanceado(t) << endl;  
	cout << "Balance t1:  " << esta_balanceado(t1) << endl; 
	cout << "Balance t2:  " << esta_balanceado(t2) << endl; 

	delete t;
	delete t1;
	delete t2;

	return 0;
}
